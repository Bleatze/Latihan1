﻿Imports System.Data.SqlClient

Public Class LaporanPenjualan

    Sub tampil()
        conn.Open()
        cmd = New SqlCommand("select tbl_transaksi.id_transaksi,tbl_barang.nama_barang,tbl_transaksi.tgl_transaksi,tbl_transaksi.total_bayar,tbl_user.nama from tbl_transaksi inner join tbl_user on tbl_transaksi.id_user = tbl_user.id_user inner join tbl_barang on tbl_transaksi.id_barang = tbl_barang.id_barang", conn)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "tbl_transaksi")
        dgv_penjualan.DataSource = (ds.Tables("tbl_transaksi"))
        conn.Close()

    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        KelolaUser.Show()
        Me.Hide()
    End Sub

    Private Sub LaporanPenjualan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call tampil()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        conn.Open()
        cmd = New SqlCommand("select tbl_transaksi.id_transaksi,tbl_barang.nama_barang,tbl_transaksi.tgl_transaksi,tbl_transaksi.total_bayar,tbl_user.nama from tbl_transaksi inner join tbl_user on tbl_transaksi.id_user = tbl_user.id_user inner join tbl_barang on tbl_transaksi.id_barang = tbl_barang.id_barang where tbl_transaksi.tgl_transaksi between '" & dtpAwal.Value.Date.ToString("yyyyMMdd") & "' and '" & dtpAkhir.Value.Date.ToString("yyyyMMdd") & "'", conn)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "tbl_transaksi")
        dgv_penjualan.DataSource = (ds.Tables("tbl_transaksi"))
        conn.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
        PrintPreviewDialog1.ShowDialog()
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim f As New Font("Arial", 12, FontStyle.Regular)
        Dim j As New Font("Arial", 14, FontStyle.Bold)
        Dim y As Integer = 10
        e.Graphics.DrawString("ID", j, Brushes.Black, 20, y)
        e.Graphics.DrawString("Nama Barang", j, Brushes.Black, 100, y)
        e.Graphics.DrawString("Tanggal", j, Brushes.Black, 300, y)
        e.Graphics.DrawString("Total", j, Brushes.Black, 500, y)
        e.Graphics.DrawString("Nama", j, Brushes.Black, 700, y)
        For i As Integer = 0 To dgv_penjualan.RowCount - 1
            y += 50
            e.Graphics.DrawString(dgv_penjualan.Rows(i).Cells(0).Value, f, Brushes.Black, 20, y)
            e.Graphics.DrawString(dgv_penjualan.Rows(i).Cells(1).Value, f, Brushes.Black, 100, y)
            e.Graphics.DrawString(dgv_penjualan.Rows(i).Cells(2).Value, f, Brushes.Black, 300, y)
            e.Graphics.DrawString(dgv_penjualan.Rows(i).Cells(3).Value, f, Brushes.Black, 500, y)
            e.Graphics.DrawString(dgv_penjualan.Rows(i).Cells(4).Value, f, Brushes.Black, 700, y)

        Next

    End Sub
End Class