﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class KelolaUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        btnLogout = New Button()
        Button1 = New Button()
        btnLogin = New Button()
        Label3 = New Label()
        Label2 = New Label()
        Button3 = New Button()
        dgv_user = New DataGridView()
        Label1 = New Label()
        cbTipeUser = New ComboBox()
        Label4 = New Label()
        Label5 = New Label()
        txtTelepon = New TextBox()
        txtNama = New TextBox()
        Label8 = New Label()
        Label6 = New Label()
        txtUsername = New TextBox()
        txtPassword = New TextBox()
        Label7 = New Label()
        txtAlamat = New TextBox()
        Button4 = New Button()
        Button5 = New Button()
        txtCari = New TextBox()
        Label9 = New Label()
        Panel1.SuspendLayout()
        CType(dgv_user, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightBlue
        Panel1.Controls.Add(btnLogout)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(btnLogin)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(-1, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(200, 500)
        Panel1.TabIndex = 12
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.White
        btnLogout.Cursor = Cursors.Hand
        btnLogout.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        btnLogout.Location = New Point(22, 341)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(147, 50)
        btnLogout.TabIndex = 8
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.White
        Button1.Cursor = Cursors.Hand
        Button1.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        Button1.Location = New Point(22, 270)
        Button1.Name = "Button1"
        Button1.Size = New Size(147, 50)
        Button1.TabIndex = 7
        Button1.Text = "Kelola Laporan"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' btnLogin
        ' 
        btnLogin.BackColor = Color.White
        btnLogin.Cursor = Cursors.Hand
        btnLogin.Enabled = False
        btnLogin.FlatAppearance.BorderColor = Color.SkyBlue
        btnLogin.FlatAppearance.BorderSize = 0
        btnLogin.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        btnLogin.Location = New Point(22, 199)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(147, 50)
        btnLogin.TabIndex = 6
        btnLogin.Text = "Kelola User"
        btnLogin.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(48, 23)
        Label3.Name = "Label3"
        Label3.Size = New Size(98, 37)
        Label3.TabIndex = 5
        Label3.Text = "Admin"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Microsoft Sans Serif", 12F)
        Label2.Location = New Point(225, 87)
        Label2.Name = "Label2"
        Label2.Size = New Size(77, 20)
        Label2.TabIndex = 17
        Label2.Text = "Tipe User"
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.White
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderColor = Color.SkyBlue
        Button3.FlatAppearance.BorderSize = 0
        Button3.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(225, 270)
        Button3.Name = "Button3"
        Button3.Size = New Size(129, 33)
        Button3.TabIndex = 13
        Button3.Text = "Tambah"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' dgv_user
        ' 
        dgv_user.AllowUserToAddRows = False
        dgv_user.AllowUserToDeleteRows = False
        dgv_user.BackgroundColor = Color.White
        dgv_user.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_user.Location = New Point(225, 353)
        dgv_user.Name = "dgv_user"
        dgv_user.ReadOnly = True
        dgv_user.Size = New Size(547, 119)
        dgv_user.TabIndex = 14
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(419, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(143, 32)
        Label1.TabIndex = 15
        Label1.Text = "Kelola User"
        ' 
        ' cbTipeUser
        ' 
        cbTipeUser.Font = New Font("Microsoft Sans Serif", 12F)
        cbTipeUser.FormattingEnabled = True
        cbTipeUser.Items.AddRange(New Object() {"Kasir", "Gudang", "Admin"})
        cbTipeUser.Location = New Point(227, 111)
        cbTipeUser.Name = "cbTipeUser"
        cbTipeUser.Size = New Size(254, 28)
        cbTipeUser.TabIndex = 18
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Microsoft Sans Serif", 12F)
        Label4.Location = New Point(225, 204)
        Label4.Name = "Label4"
        Label4.Size = New Size(66, 20)
        Label4.TabIndex = 24
        Label4.Text = "Telepon"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Microsoft Sans Serif", 12F)
        Label5.Location = New Point(227, 143)
        Label5.Name = "Label5"
        Label5.Size = New Size(51, 20)
        Label5.TabIndex = 22
        Label5.Text = "Nama"
        ' 
        ' txtTelepon
        ' 
        txtTelepon.Font = New Font("Microsoft Sans Serif", 12F)
        txtTelepon.Location = New Point(225, 224)
        txtTelepon.Name = "txtTelepon"
        txtTelepon.Size = New Size(256, 26)
        txtTelepon.TabIndex = 21
        ' 
        ' txtNama
        ' 
        txtNama.Font = New Font("Microsoft Sans Serif", 12F)
        txtNama.Location = New Point(225, 167)
        txtNama.Name = "txtNama"
        txtNama.Size = New Size(256, 26)
        txtNama.TabIndex = 20
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 12F)
        Label8.Location = New Point(516, 87)
        Label8.Name = "Label8"
        Label8.Size = New Size(59, 20)
        Label8.TabIndex = 25
        Label8.Text = "Alamat"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Microsoft Sans Serif", 12F)
        Label6.Location = New Point(516, 204)
        Label6.Name = "Label6"
        Label6.Size = New Size(78, 20)
        Label6.TabIndex = 31
        Label6.Text = "Password"
        ' 
        ' txtUsername
        ' 
        txtUsername.Font = New Font("Microsoft Sans Serif", 12F)
        txtUsername.Location = New Point(516, 167)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(256, 26)
        txtUsername.TabIndex = 28
        ' 
        ' txtPassword
        ' 
        txtPassword.Font = New Font("Microsoft Sans Serif", 12F)
        txtPassword.Location = New Point(516, 224)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(256, 26)
        txtPassword.TabIndex = 29
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 12F)
        Label7.Location = New Point(518, 143)
        Label7.Name = "Label7"
        Label7.Size = New Size(83, 20)
        Label7.TabIndex = 30
        Label7.Text = "Username"
        ' 
        ' txtAlamat
        ' 
        txtAlamat.Font = New Font("Microsoft Sans Serif", 12F)
        txtAlamat.Location = New Point(516, 111)
        txtAlamat.Name = "txtAlamat"
        txtAlamat.Size = New Size(256, 26)
        txtAlamat.TabIndex = 32
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.White
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderColor = Color.SkyBlue
        Button4.FlatAppearance.BorderSize = 0
        Button4.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(372, 270)
        Button4.Name = "Button4"
        Button4.Size = New Size(129, 33)
        Button4.TabIndex = 33
        Button4.Text = "Edit"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.White
        Button5.Cursor = Cursors.Hand
        Button5.FlatAppearance.BorderColor = Color.SkyBlue
        Button5.FlatAppearance.BorderSize = 0
        Button5.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.Location = New Point(518, 270)
        Button5.Name = "Button5"
        Button5.Size = New Size(129, 33)
        Button5.TabIndex = 34
        Button5.Text = "Hapus"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' txtCari
        ' 
        txtCari.Font = New Font("Microsoft Sans Serif", 12F)
        txtCari.Location = New Point(616, 321)
        txtCari.Name = "txtCari"
        txtCari.Size = New Size(156, 26)
        txtCari.TabIndex = 35
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(516, 323)
        Label9.Name = "Label9"
        Label9.Size = New Size(81, 21)
        Label9.TabIndex = 36
        Label9.Text = "Cari User :"
        ' 
        ' KelolaUser
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 500)
        Controls.Add(Label9)
        Controls.Add(txtCari)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(txtAlamat)
        Controls.Add(Label6)
        Controls.Add(Label7)
        Controls.Add(txtPassword)
        Controls.Add(txtUsername)
        Controls.Add(Label8)
        Controls.Add(Label4)
        Controls.Add(Label5)
        Controls.Add(txtTelepon)
        Controls.Add(txtNama)
        Controls.Add(cbTipeUser)
        Controls.Add(Panel1)
        Controls.Add(Label2)
        Controls.Add(Button3)
        Controls.Add(dgv_user)
        Controls.Add(Label1)
        FormBorderStyle = FormBorderStyle.None
        Name = "KelolaUser"
        StartPosition = FormStartPosition.CenterScreen
        Text = "KelolaUser"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(dgv_user, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnLogout As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents btnLogin As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents dgv_user As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents cbTipeUser As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtTelepon As TextBox
    Friend WithEvents txtNama As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtAlamat As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents txtCari As TextBox
    Friend WithEvents Label9 As Label
End Class
