﻿Imports System.Data.SqlClient

Public Class Login
    Sub clr()
        txtUsername.Text = ""
        txtPassword.Text = ""
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        clr()
    End Sub

    Private Sub cbShow_CheckedChanged(sender As Object, e As EventArgs) Handles cbShow.CheckedChanged
        If cbShow.Checked = True Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MessageBox.Show("Silahkan isi data terlebih dahulu")
            Exit Sub
        End If
        conn.Open()
        cmd = New SqlCommand("select * from tbl_user where username = '" & txtUsername.Text & "' and password = '" & txtPassword.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If Not (dr.HasRows) Then
            MessageBox.Show("Data anda tidak terdaftar")
            conn.Close()
            Exit Sub
        End If
        tipe_user = dr.Item("tipe_user")
        nama = dr.Item("nama")
        id_user = dr.Item("id_user")
        conn.Close()

        If tipe_user = "Admin" Then
            FormAdmin.Show()
            Call clr()
            Me.Hide()
        ElseIf tipe_user = "Kasir" Then
            FormTransaksi.Show()
            Call clr()
            Me.Hide()
        Else
            KelolaBarang.Show()
            Call clr()
            Me.Hide()
        End If

    End Sub

End Class
