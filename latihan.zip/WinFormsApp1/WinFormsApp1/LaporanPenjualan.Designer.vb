﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LaporanPenjualan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LaporanPenjualan))
        Label8 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        btnLogout = New Button()
        Button1 = New Button()
        btnLogin = New Button()
        Label3 = New Label()
        Panel1 = New Panel()
        dgv_penjualan = New DataGridView()
        dtpAwal = New DateTimePicker()
        dtpAkhir = New DateTimePicker()
        Button3 = New Button()
        Button2 = New Button()
        PrintPreviewDialog1 = New PrintPreviewDialog()
        PrintDocument1 = New Printing.PrintDocument()
        Panel1.SuspendLayout()
        CType(dgv_penjualan, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 12F)
        Label8.Location = New Point(437, 91)
        Label8.Name = "Label8"
        Label8.Size = New Size(114, 20)
        Label8.TabIndex = 47
        Label8.Text = "Tanggal Akhir :"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Microsoft Sans Serif", 12F)
        Label2.Location = New Point(226, 91)
        Label2.Name = "Label2"
        Label2.Size = New Size(112, 20)
        Label2.TabIndex = 40
        Label2.Text = "Tanggal Awal :"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(420, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(204, 32)
        Label1.TabIndex = 39
        Label1.Text = "Kelola Penjualan"
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.White
        btnLogout.Cursor = Cursors.Hand
        btnLogout.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        btnLogout.Location = New Point(22, 341)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(147, 50)
        btnLogout.TabIndex = 8
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.White
        Button1.Cursor = Cursors.Hand
        Button1.Enabled = False
        Button1.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        Button1.Location = New Point(22, 270)
        Button1.Name = "Button1"
        Button1.Size = New Size(147, 50)
        Button1.TabIndex = 7
        Button1.Text = "Kelola Laporan"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' btnLogin
        ' 
        btnLogin.BackColor = Color.White
        btnLogin.Cursor = Cursors.Hand
        btnLogin.FlatAppearance.BorderColor = Color.SkyBlue
        btnLogin.FlatAppearance.BorderSize = 0
        btnLogin.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        btnLogin.Location = New Point(22, 199)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(147, 50)
        btnLogin.TabIndex = 6
        btnLogin.Text = "Kelola User"
        btnLogin.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(48, 23)
        Label3.Name = "Label3"
        Label3.Size = New Size(98, 37)
        Label3.TabIndex = 5
        Label3.Text = "Admin"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightBlue
        Panel1.Controls.Add(btnLogout)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(btnLogin)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(200, 500)
        Panel1.TabIndex = 36
        ' 
        ' dgv_penjualan
        ' 
        dgv_penjualan.AllowUserToAddRows = False
        dgv_penjualan.AllowUserToDeleteRows = False
        dgv_penjualan.BackgroundColor = Color.White
        dgv_penjualan.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_penjualan.Location = New Point(226, 159)
        dgv_penjualan.Name = "dgv_penjualan"
        dgv_penjualan.ReadOnly = True
        dgv_penjualan.Size = New Size(547, 119)
        dgv_penjualan.TabIndex = 38
        ' 
        ' dtpAwal
        ' 
        dtpAwal.CalendarFont = New Font("Segoe UI", 12F)
        dtpAwal.Location = New Point(226, 114)
        dtpAwal.Name = "dtpAwal"
        dtpAwal.Size = New Size(189, 23)
        dtpAwal.TabIndex = 48
        ' 
        ' dtpAkhir
        ' 
        dtpAkhir.CalendarFont = New Font("Segoe UI", 12F)
        dtpAkhir.Location = New Point(437, 114)
        dtpAkhir.Name = "dtpAkhir"
        dtpAkhir.Size = New Size(189, 23)
        dtpAkhir.TabIndex = 49
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.White
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderColor = Color.SkyBlue
        Button3.FlatAppearance.BorderSize = 0
        Button3.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(644, 109)
        Button3.Name = "Button3"
        Button3.Size = New Size(129, 33)
        Button3.TabIndex = 50
        Button3.Text = "Filter"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.White
        Button2.Cursor = Cursors.Hand
        Button2.FlatAppearance.BorderColor = Color.SkyBlue
        Button2.FlatAppearance.BorderSize = 0
        Button2.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(644, 298)
        Button2.Name = "Button2"
        Button2.Size = New Size(129, 33)
        Button2.TabIndex = 51
        Button2.Text = "Print"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' PrintPreviewDialog1
        ' 
        PrintPreviewDialog1.AutoScrollMargin = New Size(0, 0)
        PrintPreviewDialog1.AutoScrollMinSize = New Size(0, 0)
        PrintPreviewDialog1.ClientSize = New Size(400, 300)
        PrintPreviewDialog1.Enabled = True
        PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), Icon)
        PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        PrintPreviewDialog1.Visible = False
        ' 
        ' PrintDocument1
        ' 
        ' 
        ' LaporanPenjualan
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(800, 500)
        Controls.Add(Button2)
        Controls.Add(Button3)
        Controls.Add(dtpAkhir)
        Controls.Add(dtpAwal)
        Controls.Add(Label8)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Panel1)
        Controls.Add(dgv_penjualan)
        FormBorderStyle = FormBorderStyle.None
        Name = "LaporanPenjualan"
        StartPosition = FormStartPosition.CenterScreen
        Text = "LporanPenjualan"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(dgv_penjualan, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents Label8 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnLogout As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents btnLogin As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dgv_penjualan As DataGridView
    Friend WithEvents dtpAwal As DateTimePicker
    Friend WithEvents dtpAkhir As DateTimePicker
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
End Class
