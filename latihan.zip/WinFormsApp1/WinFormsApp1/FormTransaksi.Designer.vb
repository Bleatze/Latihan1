﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormTransaksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label9 = New Label()
        TextBox6 = New TextBox()
        Button5 = New Button()
        txtJumlah = New TextBox()
        Label7 = New Label()
        txtTotal = New TextBox()
        TextBox4 = New TextBox()
        Label8 = New Label()
        Label5 = New Label()
        txtHarga = New TextBox()
        Label2 = New Label()
        Button3 = New Button()
        dgv_Transaksi = New DataGridView()
        ID = New DataGridViewTextBoxColumn()
        KodeBarang = New DataGridViewTextBoxColumn()
        NamaBarang = New DataGridViewTextBoxColumn()
        Harga = New DataGridViewTextBoxColumn()
        Quantitas = New DataGridViewTextBoxColumn()
        Subtotal = New DataGridViewTextBoxColumn()
        Label1 = New Label()
        btnLogout = New Button()
        Label3 = New Label()
        TextBox1 = New TextBox()
        Panel1 = New Panel()
        Label4 = New Label()
        Button1 = New Button()
        Button4 = New Button()
        Label6 = New Label()
        Label10 = New Label()
        txtKodeBarang = New TextBox()
        CType(dgv_Transaksi, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(226, 387)
        Label9.Name = "Label9"
        Label9.Size = New Size(121, 21)
        Label9.TabIndex = 58
        Label9.Text = "Total Harga : Rp."
        ' 
        ' TextBox6
        ' 
        TextBox6.Font = New Font("Microsoft Sans Serif", 12F)
        TextBox6.Location = New Point(228, 411)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(212, 26)
        TextBox6.TabIndex = 57
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.White
        Button5.Cursor = Cursors.Hand
        Button5.FlatAppearance.BorderColor = Color.SkyBlue
        Button5.FlatAppearance.BorderSize = 0
        Button5.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.Location = New Point(644, 210)
        Button5.Name = "Button5"
        Button5.Size = New Size(129, 33)
        Button5.TabIndex = 56
        Button5.Text = "Reset"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' txtJumlah
        ' 
        txtJumlah.Font = New Font("Microsoft Sans Serif", 12F)
        txtJumlah.Location = New Point(517, 111)
        txtJumlah.Name = "txtJumlah"
        txtJumlah.Size = New Size(256, 26)
        txtJumlah.TabIndex = 54
        txtJumlah.Text = "1"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 12F)
        Label7.Location = New Point(519, 143)
        Label7.Name = "Label7"
        Label7.Size = New Size(92, 20)
        Label7.TabIndex = 52
        Label7.Text = "Total Harga"
        ' 
        ' txtTotal
        ' 
        txtTotal.Enabled = False
        txtTotal.Font = New Font("Microsoft Sans Serif", 12F)
        txtTotal.Location = New Point(517, 167)
        txtTotal.Name = "txtTotal"
        txtTotal.Size = New Size(256, 26)
        txtTotal.TabIndex = 49
        ' 
        ' TextBox4
        ' 
        TextBox4.Font = New Font("Microsoft Sans Serif", 12F)
        TextBox4.Location = New Point(517, 167)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(256, 26)
        TextBox4.TabIndex = 50
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 12F)
        Label8.Location = New Point(517, 87)
        Label8.Name = "Label8"
        Label8.Size = New Size(78, 20)
        Label8.TabIndex = 48
        Label8.Text = "Quantitas"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Microsoft Sans Serif", 12F)
        Label5.Location = New Point(228, 143)
        Label5.Name = "Label5"
        Label5.Size = New Size(109, 20)
        Label5.TabIndex = 46
        Label5.Text = "Harga Satuan"
        ' 
        ' txtHarga
        ' 
        txtHarga.Enabled = False
        txtHarga.Font = New Font("Microsoft Sans Serif", 12F)
        txtHarga.Location = New Point(226, 167)
        txtHarga.Name = "txtHarga"
        txtHarga.Size = New Size(256, 26)
        txtHarga.TabIndex = 44
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Microsoft Sans Serif", 12F)
        Label2.Location = New Point(226, 87)
        Label2.Name = "Label2"
        Label2.Size = New Size(102, 20)
        Label2.TabIndex = 41
        Label2.Text = "Kode Barang"
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.White
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderColor = Color.SkyBlue
        Button3.FlatAppearance.BorderSize = 0
        Button3.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(500, 210)
        Button3.Name = "Button3"
        Button3.Size = New Size(129, 33)
        Button3.TabIndex = 38
        Button3.Text = "Tambah"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' dgv_Transaksi
        ' 
        dgv_Transaksi.AllowUserToAddRows = False
        dgv_Transaksi.AllowUserToDeleteRows = False
        dgv_Transaksi.BackgroundColor = Color.White
        dgv_Transaksi.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_Transaksi.Columns.AddRange(New DataGridViewColumn() {ID, KodeBarang, NamaBarang, Harga, Quantitas, Subtotal})
        dgv_Transaksi.Location = New Point(226, 249)
        dgv_Transaksi.Name = "dgv_Transaksi"
        dgv_Transaksi.ReadOnly = True
        dgv_Transaksi.Size = New Size(547, 119)
        dgv_Transaksi.TabIndex = 39
        ' 
        ' ID
        ' 
        ID.HeaderText = "ID Transaksi"
        ID.Name = "ID"
        ID.ReadOnly = True
        ' 
        ' KodeBarang
        ' 
        KodeBarang.HeaderText = "Kode Barang"
        KodeBarang.Name = "KodeBarang"
        KodeBarang.ReadOnly = True
        ' 
        ' NamaBarang
        ' 
        NamaBarang.HeaderText = "Nama Barang"
        NamaBarang.Name = "NamaBarang"
        NamaBarang.ReadOnly = True
        ' 
        ' Harga
        ' 
        Harga.HeaderText = "Harga Satuan"
        Harga.Name = "Harga"
        Harga.ReadOnly = True
        ' 
        ' Quantitas
        ' 
        Quantitas.HeaderText = "Quantitas"
        Quantitas.Name = "Quantitas"
        Quantitas.ReadOnly = True
        ' 
        ' Subtotal
        ' 
        Subtotal.HeaderText = "Subtotal"
        Subtotal.Name = "Subtotal"
        Subtotal.ReadOnly = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(420, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(143, 32)
        Label1.TabIndex = 40
        Label1.Text = "Kelola User"
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.White
        btnLogout.Cursor = Cursors.Hand
        btnLogout.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        btnLogout.Location = New Point(26, 422)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(147, 50)
        btnLogout.TabIndex = 8
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(62, 19)
        Label3.Name = "Label3"
        Label3.Size = New Size(77, 37)
        Label3.TabIndex = 5
        Label3.Text = "Kasir"
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Microsoft Sans Serif", 12F)
        TextBox1.Location = New Point(226, 167)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(256, 26)
        TextBox1.TabIndex = 43
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightBlue
        Panel1.Controls.Add(btnLogout)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(197, 500)
        Panel1.TabIndex = 37
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(228, 440)
        Label4.Name = "Label4"
        Label4.Size = New Size(116, 21)
        Label4.TabIndex = 59
        Label4.Text = "Kembalian : Rp."
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.White
        Button1.Cursor = Cursors.Hand
        Button1.FlatAppearance.BorderColor = Color.SkyBlue
        Button1.FlatAppearance.BorderSize = 0
        Button1.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(644, 439)
        Button1.Name = "Button1"
        Button1.Size = New Size(129, 33)
        Button1.TabIndex = 61
        Button1.Text = "Bayar"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.White
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderColor = Color.SkyBlue
        Button4.FlatAppearance.BorderSize = 0
        Button4.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(500, 439)
        Button4.Name = "Button4"
        Button4.Size = New Size(129, 33)
        Button4.TabIndex = 60
        Button4.Text = "Print"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(353, 440)
        Label6.Name = "Label6"
        Label6.RightToLeft = RightToLeft.No
        Label6.Size = New Size(40, 21)
        Label6.TabIndex = 62
        Label6.Text = "kem"
        Label6.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(353, 387)
        Label10.Name = "Label10"
        Label10.RightToLeft = RightToLeft.Yes
        Label10.Size = New Size(29, 21)
        Label10.TabIndex = 63
        Label10.Text = "tot"
        Label10.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' txtKodeBarang
        ' 
        txtKodeBarang.Font = New Font("Microsoft Sans Serif", 12F)
        txtKodeBarang.Location = New Point(226, 110)
        txtKodeBarang.Name = "txtKodeBarang"
        txtKodeBarang.Size = New Size(256, 26)
        txtKodeBarang.TabIndex = 64
        ' 
        ' FormTransaksi
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(800, 500)
        Controls.Add(txtKodeBarang)
        Controls.Add(Label10)
        Controls.Add(Label6)
        Controls.Add(Button1)
        Controls.Add(Button4)
        Controls.Add(Label4)
        Controls.Add(Label9)
        Controls.Add(Button5)
        Controls.Add(txtJumlah)
        Controls.Add(TextBox6)
        Controls.Add(Label7)
        Controls.Add(txtTotal)
        Controls.Add(TextBox4)
        Controls.Add(Label8)
        Controls.Add(Label5)
        Controls.Add(txtHarga)
        Controls.Add(Label2)
        Controls.Add(Button3)
        Controls.Add(dgv_Transaksi)
        Controls.Add(Label1)
        Controls.Add(TextBox1)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "FormTransaksi"
        StartPosition = FormStartPosition.CenterScreen
        Text = "FormTransaksi"
        CType(dgv_Transaksi, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Button5 As Button
    Friend WithEvents txtJumlah As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtHarga As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents dgv_Transaksi As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents btnLogout As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtKodeBarang As TextBox
    Friend WithEvents ID As DataGridViewTextBoxColumn
    Friend WithEvents KodeBarang As DataGridViewTextBoxColumn
    Friend WithEvents NamaBarang As DataGridViewTextBoxColumn
    Friend WithEvents Harga As DataGridViewTextBoxColumn
    Friend WithEvents Quantitas As DataGridViewTextBoxColumn
    Friend WithEvents Subtotal As DataGridViewTextBoxColumn
End Class
