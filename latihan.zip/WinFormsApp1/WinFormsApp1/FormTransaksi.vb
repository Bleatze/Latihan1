﻿Imports System.Data.SqlClient

Public Class FormTransaksi

    Dim auto_id As Integer
    Dim jumlahbarang As Integer
    Dim jumlah As Integer
    Dim total As Integer
    Dim keseluruhan As Integer
    Dim uang As Integer
    Dim kembalian As Integer
    Dim jumlahkeseluruhan As Integer = 0
    Dim temp As Integer

    Sub autoId()
        conn.Open()
        cmd = New SqlCommand("select * from tbl_transaksi order by id_transaksi desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            auto_id = Val(dr(0) + 1)
        Else
            auto_id = 1
        End If
        conn.Close()
    End Sub

    Private Sub FormTransaksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call autoId()
        Label10.Text = "0"
        Label6.Text = "0"
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub txtKodeBarang_TextChanged(sender As Object, e As EventArgs) Handles txtKodeBarang.TextChanged
        conn.Open()
        cmd = New SqlCommand("select * from tbl_barang where kode_barang = '" & txtKodeBarang.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            jumlah = Val(dr(6))
            txtHarga.Text = jumlah
            jumlahbarang = Val(txtJumlah.Text)
            total = jumlah * jumlahbarang
            txtTotal.Text = total
        Else
            txtHarga.Text = ""
            txtTotal.Text = "0"
        End If
        dr.Close()
        conn.Close()
    End Sub

    Private Sub txtJumlah_TextChanged(sender As Object, e As EventArgs) Handles txtJumlah.TextChanged
        If Not (IsNumeric(txtJumlah.Text)) And Not (txtJumlah.Text = "") Then
            MessageBox.Show("Silahkan isi data dengan tipe data yang benar")
            Exit Sub
        End If
        jumlahbarang = Val(txtJumlah.Text)
        total = jumlah * jumlahbarang
        txtTotal.Text = total
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If txtKodeBarang.Text = "" Or txtHarga.Text = "" Or txtJumlah.Text = "" Or txtTotal.Text = "0" Then
            MessageBox.Show("Isi data dengan valid")
            Exit Sub
        End If
        If Not (IsNumeric(txtJumlah.Text)) Then
            MessageBox.Show("Silahkan isi data dengan tipe data yang benar")
            Exit Sub
        End If
        conn.Open()
        cmd = New SqlCommand("select * from tbl_barang where kode_barang = '" & txtKodeBarang.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If jumlahkeseluruhan = 0 Then
            temp = jumlahkeseluruhan
            jumlahkeseluruhan = dr(4) - Val(txtJumlah.Text)
        ElseIf jumlahkeseluruhan > 0 Then
            temp = jumlahkeseluruhan
            jumlahkeseluruhan -= Val(txtJumlah.Text)
        End If
        If jumlahkeseluruhan < 0 Then
            MessageBox.Show("Jumlah barang tidak mencukupi")
            jumlahkeseluruhan = temp
            conn.Close()
            Exit Sub
        End If
        dgv_Transaksi.Rows.Add(New String() {auto_id, txtKodeBarang.Text, dr(2), txtHarga.Text, txtJumlah.Text, txtTotal.Text})
        keseluruhan = keseluruhan + total
        Label10.Text = keseluruhan
        dr.Close()
        conn.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        dgv_Transaksi.Rows.Clear()
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        If Not (IsNumeric(TextBox6.Text)) And Not (TextBox6.Text = "") Then
            MessageBox.Show("Silahkan isi data dengan tipe data yang benar")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            Label6.Text = ""
        End If
        uang = Val(TextBox6.Text)
        kembalian = uang - keseluruhan
        Label6.Text = kembalian
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If kembalian < 0 Or TextBox6.Text = "" Then
            MessageBox.Show("Uang yang dimasukkan kurang")
            Exit Sub
        End If
        For i As Integer = 0 To dgv_Transaksi.RowCount - 1
            conn.Open()
            cmd = New SqlCommand("select * from tbl_barang where kode_barang = '" & dgv_Transaksi.Rows(i).Cells(1).Value.ToString & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                Dim updateQuery As String = "update tbl_barang set jumlah_barang = '" & jumlahkeseluruhan & "' where kode_barang = '" & dgv_Transaksi.Rows(i).Cells(1).Value.ToString & "'"
                conn.Close()
                ExecuteQuery(updateQuery)
            End If
            conn.Open()
            cmd = New SqlCommand("select * from tbl_barang where kode_barang = '" & dgv_Transaksi.Rows(i).Cells(1).Value.ToString & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            Dim insertQuery As String = "insert into tbl_transaksi values('" & auto_id & "','" & auto_id & "','" & Date.Now.ToString("yyyyMMdd") & "','" & dgv_Transaksi.Rows(i).Cells(5).Value.ToString & "','" & id_user & "','" & dr(0) & "')"
            conn.Close()
            ExecuteQuery(insertQuery)
            Call autoId()
        Next
        Label10.Text = "0"
        TextBox6.Text = ""
        Label6.Text = "0"
        MessageBox.Show("Transaksi telah berhasil")
    End Sub
End Class