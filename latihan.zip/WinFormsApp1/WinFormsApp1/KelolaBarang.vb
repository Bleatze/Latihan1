﻿Imports System.Data.SqlClient
Imports System.Runtime.CompilerServices

Public Class KelolaBarang

    Dim auto_id As Integer
    Dim id_check As Integer

    Sub tampil()
        conn.Open()
        cmd = New SqlCommand("select * from tbl_barang", conn)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "tbl_barang")
        dgv_barang.DataSource = (ds.Tables("tbl_barang"))
        conn.Close()
    End Sub

    Sub autoId()
        conn.Open()
        cmd = New SqlCommand("select * from tbl_barang order by id_barang desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            auto_id = Val(dr(0) + 1)
        Else
            auto_id = 1
        End If
        conn.Close()
    End Sub

    Sub clr()
        txtKodeBarang.Text = ""
        txtNamaBarang.Text = ""
        dtpExpired.Value = Now
        txtJumlahBarang.Text = ""
        txtSatuan.Text = ""
        txtHarga.Text = ""
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If txtKodeBarang.Text = "" Or txtNamaBarang.Text = "" Or txtJumlahBarang.Text = "" Or txtSatuan.Text = "" Or txtHarga.Text = "" Then
            MessageBox.Show("Silahkan isi seluruh data barang terlebih dahulu")
            Exit Sub
        End If
        If Not (IsNumeric(txtJumlahBarang.Text)) Or Not (IsNumeric(txtHarga.Text)) Then
            MessageBox.Show("Silahkan isi data dengan tipe data yang benar")
            Exit Sub
        End If
        Try
            conn.Open()
            cmd = New SqlCommand("select * from tbl_barang where kode_barang = '" & txtKodeBarang.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                MessageBox.Show("Kode Barang tidak boleh sama dengan barang yang sudah terdaftar")
                Exit Sub
            End If
        Catch ex As Exception

        Finally
            conn.Close()
        End Try
        Dim insertQuery As String = "insert into tbl_barang values('" & auto_id & "','" & txtKodeBarang.Text & "','" & txtNamaBarang.Text & "','" & dtpExpired.Value.Date.ToString("yyyyMMdd") & "','" & txtJumlahBarang.Text & "','" & txtSatuan.Text & "','" & txtHarga.Text & "')"
        ExecuteQuery(insertQuery)
        Call tampil()
        Call autoId()
        Call clr()
    End Sub

    Private Sub KelolaBarang_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call autoId()
        Call tampil()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If txtKodeBarang.Text = "" Or txtNamaBarang.Text = "" Or txtJumlahBarang.Text = "" Or txtSatuan.Text = "" Or txtHarga.Text = "" Then
            MessageBox.Show("Silahkan isi seluruh data barang terlebih dahulu")
            Exit Sub
        End If
        If Not (IsNumeric(txtJumlahBarang.Text)) Or Not (IsNumeric(txtHarga.Text)) Then
            MessageBox.Show("Silahkan isi data dengan tipe data yang benar")
            Exit Sub
        End If
        Try
            conn.Open()
            cmd = New SqlCommand("select * from tbl_barang where kode_barang = '" & txtKodeBarang.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not (dr.HasRows) Then
                MessageBox.Show("Kode Barang tidak terdaftar")
                conn.Close()
                Exit Sub
            End If
        Catch ex As Exception

        End Try
        conn.Close()

        Try
            Dim updateQuery As String = "update tbl_barang set nama_barang = '" & txtNamaBarang.Text & "', expired_date = '" & dtpExpired.Value.Date.ToString("yyyyMMdd") & "', jumlah_barang = '" & txtJumlahBarang.Text & "', satuan = '" & txtSatuan.Text & "', harga_satuan = '" & txtHarga.Text & "' where id_barang = '" & id_check & "' and kode_barang = '" & txtKodeBarang.Text & "'"
            ExecuteQuery(updateQuery)
        Catch ex As Exception

        End Try
        conn.Close()
        Call tampil()
        Call autoId()
        Call clr()
    End Sub

    Private Sub dgv_barang_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgv_barang.CellMouseClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgv_barang.Rows(e.RowIndex)
            id_check = row.Cells(0).Value.ToString
            txtKodeBarang.Text = row.Cells(1).Value.ToString
            txtNamaBarang.Text = row.Cells(2).Value.ToString
            dtpExpired.Value = row.Cells(3).Value
            txtJumlahBarang.Text = row.Cells(4).Value.ToString
            txtSatuan.Text = row.Cells(5).Value.ToString
            txtHarga.Text = row.Cells(6).Value.ToString
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            conn.Open()
            cmd = New SqlCommand("select * from tbl_barang where kode_barang = '" & txtKodeBarang.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If Not (dr.HasRows) Then
                MessageBox.Show("Kode Barang tidak terdaftar")
                conn.Close()
                Exit Sub
            End If
        Catch ex As Exception

        End Try
        conn.Close()
        Try
            Dim deletequery As String = "delete from tbl_barang where id_barang = '" & id_check & "' and kode_barang = '" & txtKodeBarang.Text & "'"
            ExecuteQuery(deletequery)
        Catch ex As Exception

        End Try
        conn.Close()
        Call tampil()
        Call autoId()
        Call clr()
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        conn.Open()
        cmd = New SqlCommand("select * from tbl_barang where id_barang LIKE '" & txtCari.Text & "%' or nama_barang LIKE '" & txtCari.Text & "%'", conn)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "tbl_barang")
        dgv_barang.DataSource = (ds.Tables("tbl_barang"))
        conn.Close()
    End Sub
End Class