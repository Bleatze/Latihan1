﻿Imports System.Data.SqlClient

Module Module1
    Public conn As SqlConnection = New SqlConnection("data source=DESKTOP-DF1N3J1;initial catalog=FOOD_XYZ;integrated security=true")
    Public cmd As SqlCommand
    Public da As SqlDataAdapter
    Public dr As SqlDataReader
    Public ds As DataSet
    Public dt As DataTable
    Public tipe_user As String
    Public nama As String
    Public id_user As Integer

    Public Sub ExecuteQuery(ByVal query As String)
        cmd = New SqlCommand(query, conn)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub
End Module
