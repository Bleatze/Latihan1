﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class KelolaBarang
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label9 = New Label()
        txtCari = New TextBox()
        Button5 = New Button()
        Button4 = New Button()
        txtJumlahBarang = New TextBox()
        Label6 = New Label()
        Label7 = New Label()
        txtHarga = New TextBox()
        txtSatuan = New TextBox()
        Label8 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label2 = New Label()
        Button3 = New Button()
        dgv_barang = New DataGridView()
        Label1 = New Label()
        btnLogout = New Button()
        Label3 = New Label()
        txtNamaBarang = New TextBox()
        Panel1 = New Panel()
        txtKodeBarang = New TextBox()
        dtpExpired = New DateTimePicker()
        CType(dgv_barang, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(504, 323)
        Label9.Name = "Label9"
        Label9.Size = New Size(98, 21)
        Label9.TabIndex = 58
        Label9.Text = "Cari Barang :"
        ' 
        ' txtCari
        ' 
        txtCari.Font = New Font("Microsoft Sans Serif", 12F)
        txtCari.Location = New Point(617, 321)
        txtCari.Name = "txtCari"
        txtCari.Size = New Size(156, 26)
        txtCari.TabIndex = 57
        ' 
        ' Button5
        ' 
        Button5.BackColor = Color.White
        Button5.Cursor = Cursors.Hand
        Button5.FlatAppearance.BorderColor = Color.SkyBlue
        Button5.FlatAppearance.BorderSize = 0
        Button5.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.Location = New Point(519, 270)
        Button5.Name = "Button5"
        Button5.Size = New Size(129, 33)
        Button5.TabIndex = 56
        Button5.Text = "Hapus"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.White
        Button4.Cursor = Cursors.Hand
        Button4.FlatAppearance.BorderColor = Color.SkyBlue
        Button4.FlatAppearance.BorderSize = 0
        Button4.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(373, 270)
        Button4.Name = "Button4"
        Button4.Size = New Size(129, 33)
        Button4.TabIndex = 55
        Button4.Text = "Edit"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' txtJumlahBarang
        ' 
        txtJumlahBarang.Font = New Font("Microsoft Sans Serif", 12F)
        txtJumlahBarang.Location = New Point(517, 111)
        txtJumlahBarang.Name = "txtJumlahBarang"
        txtJumlahBarang.Size = New Size(256, 26)
        txtJumlahBarang.TabIndex = 54
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Microsoft Sans Serif", 12F)
        Label6.Location = New Point(517, 204)
        Label6.Name = "Label6"
        Label6.Size = New Size(137, 20)
        Label6.TabIndex = 53
        Label6.Text = "Harga Per Satuan"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Microsoft Sans Serif", 12F)
        Label7.Location = New Point(519, 143)
        Label7.Name = "Label7"
        Label7.Size = New Size(61, 20)
        Label7.TabIndex = 52
        Label7.Text = "Satuan"
        ' 
        ' txtHarga
        ' 
        txtHarga.Font = New Font("Microsoft Sans Serif", 12F)
        txtHarga.Location = New Point(517, 224)
        txtHarga.Name = "txtHarga"
        txtHarga.Size = New Size(256, 26)
        txtHarga.TabIndex = 51
        ' 
        ' txtSatuan
        ' 
        txtSatuan.Font = New Font("Microsoft Sans Serif", 12F)
        txtSatuan.Location = New Point(517, 167)
        txtSatuan.Name = "txtSatuan"
        txtSatuan.Size = New Size(256, 26)
        txtSatuan.TabIndex = 50
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Microsoft Sans Serif", 12F)
        Label8.Location = New Point(517, 87)
        Label8.Name = "Label8"
        Label8.Size = New Size(116, 20)
        Label8.TabIndex = 48
        Label8.Text = "Jumlah Barang"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Microsoft Sans Serif", 12F)
        Label4.Location = New Point(226, 204)
        Label4.Name = "Label4"
        Label4.Size = New Size(101, 20)
        Label4.TabIndex = 47
        Label4.Text = "Expired Date"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Microsoft Sans Serif", 12F)
        Label5.Location = New Point(228, 143)
        Label5.Name = "Label5"
        Label5.Size = New Size(107, 20)
        Label5.TabIndex = 46
        Label5.Text = "Nama Barang"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Microsoft Sans Serif", 12F)
        Label2.Location = New Point(226, 87)
        Label2.Name = "Label2"
        Label2.Size = New Size(102, 20)
        Label2.TabIndex = 41
        Label2.Text = "Kode Barang"
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.White
        Button3.Cursor = Cursors.Hand
        Button3.FlatAppearance.BorderColor = Color.SkyBlue
        Button3.FlatAppearance.BorderSize = 0
        Button3.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(226, 270)
        Button3.Name = "Button3"
        Button3.Size = New Size(129, 33)
        Button3.TabIndex = 38
        Button3.Text = "Tambah"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' dgv_barang
        ' 
        dgv_barang.AllowUserToAddRows = False
        dgv_barang.AllowUserToDeleteRows = False
        dgv_barang.BackgroundColor = Color.White
        dgv_barang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgv_barang.Location = New Point(226, 353)
        dgv_barang.Name = "dgv_barang"
        dgv_barang.ReadOnly = True
        dgv_barang.Size = New Size(547, 119)
        dgv_barang.TabIndex = 39
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(420, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(173, 32)
        Label1.TabIndex = 40
        Label1.Text = "Kelola Barang"
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.White
        btnLogout.Cursor = Cursors.Hand
        btnLogout.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold)
        btnLogout.Location = New Point(27, 422)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(147, 50)
        btnLogout.TabIndex = 8
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(39, 23)
        Label3.Name = "Label3"
        Label3.Size = New Size(114, 37)
        Label3.TabIndex = 5
        Label3.Text = "Gudang"
        ' 
        ' txtNamaBarang
        ' 
        txtNamaBarang.Font = New Font("Microsoft Sans Serif", 12F)
        txtNamaBarang.Location = New Point(226, 167)
        txtNamaBarang.Name = "txtNamaBarang"
        txtNamaBarang.Size = New Size(256, 26)
        txtNamaBarang.TabIndex = 43
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightBlue
        Panel1.Controls.Add(btnLogout)
        Panel1.Controls.Add(Label3)
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(200, 500)
        Panel1.TabIndex = 37
        ' 
        ' txtKodeBarang
        ' 
        txtKodeBarang.Font = New Font("Microsoft Sans Serif", 12F)
        txtKodeBarang.Location = New Point(228, 114)
        txtKodeBarang.Name = "txtKodeBarang"
        txtKodeBarang.Size = New Size(256, 26)
        txtKodeBarang.TabIndex = 59
        ' 
        ' dtpExpired
        ' 
        dtpExpired.CalendarFont = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        dtpExpired.Location = New Point(228, 227)
        dtpExpired.Name = "dtpExpired"
        dtpExpired.Size = New Size(254, 23)
        dtpExpired.TabIndex = 60
        ' 
        ' KelolaBarang
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(800, 500)
        Controls.Add(dtpExpired)
        Controls.Add(txtKodeBarang)
        Controls.Add(Label9)
        Controls.Add(txtCari)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(txtJumlahBarang)
        Controls.Add(Label6)
        Controls.Add(Label7)
        Controls.Add(txtHarga)
        Controls.Add(txtSatuan)
        Controls.Add(Label8)
        Controls.Add(Label4)
        Controls.Add(Label5)
        Controls.Add(Label2)
        Controls.Add(Button3)
        Controls.Add(dgv_barang)
        Controls.Add(Label1)
        Controls.Add(txtNamaBarang)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "KelolaBarang"
        StartPosition = FormStartPosition.CenterScreen
        Text = "KelolaBarang"
        CType(dgv_barang, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label9 As Label
    Friend WithEvents txtCari As TextBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents txtJumlahBarang As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtHarga As TextBox
    Friend WithEvents txtSatuan As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents dgv_barang As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents btnLogout As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents txtNamaBarang As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtKodeBarang As TextBox
    Friend WithEvents dtpExpired As DateTimePicker
End Class
