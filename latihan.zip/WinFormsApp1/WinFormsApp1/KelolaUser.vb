﻿Imports System.Data.SqlClient

Public Class KelolaUser

    Dim auto_id As Integer
    Dim id_check As Integer
    Dim nama_check As String

    Sub tampil()
        conn.Open()
        cmd = New SqlCommand("select * from tbl_user", conn)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "tbl_user")
        dgv_user.DataSource = (ds.Tables("tbl_user"))
        conn.Close()
    End Sub

    Sub autoId()
        conn.Open()
        cmd = New SqlCommand("select * from tbl_user order by id_user desc", conn)
        dr = cmd.ExecuteReader
        dr.Read()
        If dr.HasRows Then
            auto_id = Val(dr(0) + 1)
        Else
            auto_id = 1
        End If
        conn.Close()
    End Sub

    Sub clr()
        cbTipeUser.Text = ""
        txtNama.Text = ""
        txtTelepon.Text = ""
        txtAlamat.Text = ""
        txtUsername.Text = ""
        txtPassword.Text = ""
    End Sub
    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Login.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LaporanPenjualan.Show()
        Me.Hide()
    End Sub

    Private Sub KelolaUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbTipeUser.Text = "Kasir"
        Call tampil()
        Call autoId()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If cbTipeUser.Text = "" Or txtNama.Text = "" Or txtTelepon.Text = "" Or txtAlamat.Text = "" Or txtUsername.Text = "" Or txtPassword.Text = "" Then
            MessageBox.Show("Silahkan isi seluruh data barang terlebih dahulu")
            Exit Sub
        End If
        Try
            conn.Open()
            cmd = New SqlCommand("select * from tbl_user where username = '" & txtUsername.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                MessageBox.Show("Username telah dipakai, silahkan ganti username")
                Exit Sub
            End If
        Catch ex As Exception

        Finally
            conn.Close()
        End Try
        Dim insertQuery As String = "insert into tbl_user values('" & auto_id & "','" & cbTipeUser.Text & "','" & txtNama.Text & "','" & txtAlamat.Text & "','" & txtTelepon.Text & "','" & txtUsername.Text & "','" & txtPassword.Text & "')"
        ExecuteQuery(insertQuery)
        Call tampil()
        Call autoId()
        Call clr()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If cbTipeUser.Text = "" Or txtNama.Text = "" Or txtTelepon.Text = "" Or txtAlamat.Text = "" Or txtUsername.Text = "" Or txtPassword.Text = "" Then
            MessageBox.Show("Silahkan isi seluruh data barang terlebih dahulu")
            Exit Sub
        End If
        Try
            If nama_check = txtUsername.Text Then
                Exit Try
            End If
            conn.Open()
            cmd = New SqlCommand("select * from tbl_user where username = '" & txtUsername.Text & "'", conn)
            dr = cmd.ExecuteReader
            dr.Read()
            If dr.HasRows Then
                MessageBox.Show("Username telah dipakai, silahkan ganti username")
                Exit Sub
            End If
        Catch ex As Exception

        Finally
            dr.Close()
            conn.Close()
        End Try
        Dim updateQuery As String = "update tbl_user set tipe_user = '" & cbTipeUser.Text & "', nama = '" & txtNama.Text & "', alamat = '" & txtAlamat.Text & "', telepon = '" & txtTelepon.Text & "', username = '" & txtUsername.Text & "', password = '" & txtPassword.Text & "' where id_user = '" & id_check & "'"
        ExecuteQuery(updateQuery)
        Call tampil()
        Call autoId()
        Call clr()
    End Sub

    Private Sub dgv_user_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgv_user.CellMouseClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgv_user.Rows(e.RowIndex)
            id_check = row.Cells(0).Value.ToString
            cbTipeUser.Text = row.Cells(1).Value.ToString
            txtNama.Text = row.Cells(2).Value.ToString
            txtTelepon.Text = row.Cells(3).Value.ToString
            txtAlamat.Text = row.Cells(4).Value.ToString
            txtUsername.Text = row.Cells(5).Value.ToString
            nama_check = row.Cells(5).Value.ToString
            txtPassword.Text = row.Cells(6).Value.ToString
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim deletequery As String = "delete from tbl_user where id_user = '" & id_check & "'"
        ExecuteQuery(deletequery)
        Call tampil()
        Call autoId()
        Call clr()
    End Sub

    Private Sub txtCari_TextChanged(sender As Object, e As EventArgs) Handles txtCari.TextChanged
        conn.Open()
        cmd = New SqlCommand("select * from tbl_user where id_user LIKE '" & txtCari.Text & "%' or nama LIKE '" & txtCari.Text & "%' or username LIKE '" & txtCari.Text & "%'", conn)
        da = New SqlDataAdapter(cmd)
        ds = New DataSet
        da.Fill(ds, "tbl_user")
        dgv_user.DataSource = (ds.Tables("tbl_user"))
        conn.Close()
    End Sub
End Class